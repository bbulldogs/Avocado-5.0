#include <kipr/botball.h>

int main()
{
    motor(0, 150);   // Turns on motor 0 at 150 power
    motor(1, 150);   // Turns on motor 1 at 150 power
    msleep(2700);    // Waits 2.7 secs before next line
    
    motor(0, -150);  // Turns on motor 0 at -150 power
    motor(1, 150);   // Turns on motor 1 at 150 power
    msleep(500);     // Waits .5 secs before next line
    
    motor(0, 150);   // Turns on motor 0 at 150 power
    motor(1, 150);   // Turns on motor 1 at 150 power
    msleep(1600);    // Waits 1.4 secs before next line
    
    motor(0, 150);   // Turns on motor 0 at 150 power
    motor(1, -150);  // Turns on motor 1 at -150 power
    msleep(450);     // Waits .45 secs before next line
    
    enable_servos(); // Turns on servo ports
    set_servo_position(1, 1761);   // Moves servo in port 1 to 1761 position
    
    motor(0, 0);     // Turns on motor 0 at 0 power
    motor(1, 0);     // Turns on motor 1 at 1 power
    msleep(2000);    // Waits 2 secs before next line
    
    set_servo_position(1, 0);      // Moves servo in port 1 to 0 position
    
    motor(0, 150);   // Turns on motor 0 at 150 power
    motor(1, -150);  // Turns on motor 1 at -150 power
    msleep(600);     // Waits .6 secs before next line
    
    motor(0, 150);   // Turns on motor 0 at 150 power
    motor(1, 150);   // Turns on motor 1 at 150 power
    msleep(2000);    // Waits 2 secs before next line
    
    motor(0, -150);  // Turns on motor 0 at -150 power
    motor(1, 150);   // Turns on motor 1 at 150 power
    msleep(600);     // Waits .6 secs before next line
    
    set_servo_position(1, 1761);   // Moves servo in port 1 to 1761 position
    
    motor(0, 0);     // Turns on motor 0 at 0 power
    motor(1, 0);     // Turns on motor 1 at 0 power
    msleep(2000);    // Waits 2 secs before next line
    
    set_servo_position(1, 0);      // Moves servo in port 1 to 0 position
    
    motor(0, -150);  // Turns on motor 0 at -150 power
    motor(1, -150);  // Turns on motor 1 at -150 power
    msleep(2700);    // Waits 2.7 secs before next line
    
    motor(0, 150);   // Turns on motor 0 at 150 power
    motor(1, -150);  // Turns on motor 1 at -150 power
    msleep(600);     // Waits .6 secs before next line
    
    motor(0, 150);   // Turns on motor 0 at 150 power
    motor(1, 150);   // Turns on motor 1 at 150 power
    msleep(1000);    // Waits 1 sec before next line
  
    return 0;        
    disable_servos();//Turns off servo ports
    ao();            // Turns all motor ports off
}
